#ifndef  __APPLICATION_H__
#define  __APPLICATION_H__
void Task_Start(void);
void LEDlight(void);
void Beep(void);
#endif

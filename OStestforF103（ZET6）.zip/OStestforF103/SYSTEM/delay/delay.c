#include "delay.h"
	#include "sys.h"
#include "includes.h"
extern void IntCtxSw(void);
void SysTick_Handler(void)
{	
	int i;
	OS_CPU_SR  cpu_sr = 0;
	if(Running == 1)
	{
		for(i=0;i<8;i++)//�����е�TCBDly��һ
		{
			if(TCBPrioTbl[i]->TCBDly != 0)
			{
				TCBPrioTbl[i]->TCBDly--;
				if(TCBPrioTbl[i]->TCBDly == 0)
				{
					TCBPrioTbl[i]->TCBStat = 0x00;
				}
			}
		}
		OS_ENTER_CRITICAL();
		SchedNew();
		if (PrioHighRdy != PrioCur) 
			{          /* No Ctx Sw if current task is highest rdy */
				TCBHighRdy  = TCBPrioTbl[PrioHighRdy];
				IntCtxSw();                          /* Perform interrupt level ctx switch       */
			}
    OS_EXIT_CRITICAL();
	}
}

			   
//��ʼ���ӳٺ���
//��ʹ��OS��ʱ��,�˺������ʼ��OS��ʱ�ӽ���
//SYSTICK��ʱ�ӹ̶�ΪHCLKʱ�ӵ�1/8
//SYSCLK:ϵͳʱ��
void delay_init()
{
    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);
	  SysTick_Config(SystemCoreClock/1000);
}			

//�ж��ӳٺ���
void OSTimeDelay(unsigned int time)
{
	TCBCur->TCBDly = time;
	TCBCur->TCBStat = 0x01;
	Sched();
}


















